
public class Plan {
/*
 * if (containers.size == 1 ){
 * 	auto set cup as container
 * }
 * 
 * else {
 * let them choose which container
 * 
 * 
 * }
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
}
