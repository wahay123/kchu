
public class Smoothie {
// array that contains ingredient and container
	
}
