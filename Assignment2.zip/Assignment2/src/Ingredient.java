
public abstract class Ingredient {
	private String name;
	private int vol;
	private boolean isContainer;

	
	abstract void add();
	abstract void setName(String name);
	abstract String getName();
	abstract void setVol(int vol);
	abstract int getVol();
	
	



	
}

