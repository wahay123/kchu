
public interface ContainerInterface {
	
	String getContainerName();
	int getContainerVol();
}
