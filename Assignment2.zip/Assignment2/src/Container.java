
public abstract class Container implements ContainerInterface{
	private String name;
	private int vol;
	
	abstract String getName();
	abstract int getVol();
	
}
